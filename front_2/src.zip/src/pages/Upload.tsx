import { useState, useEffect } from 'react';
import { LyricDisplay } from '@/components/LyricDisplay';
import { AudioPlayer } from '@/components/AudioPlayer';
import { SongInfo } from '@/components/SongInfo';
import { SongUploader } from '@/components/SongUploader';
import { BeatReactiveBackground } from '@/components/BeatReactiveBackground';
import { ThemeToggle } from '@/components/ThemeToggle';
import { LyricCustomizer } from '@/components/LyricCustomizer';
import { TextPressure } from '@/components/TextPressure';
import { ProgressiveIndicator } from '@/components/ProgressiveIndicator';
import { GuidedHints } from '@/components/GuidedHints';
import { DynamicThemeProvider, useDynamicTheme } from '@/components/DynamicThemeProvider';
import { DynamicThemeToggle } from '@/components/DynamicThemeToggle';
import { useNavigate } from 'react-router-dom';

interface SongData {
  audioUrl: string;
  lyrics: any[];
  songInfo: {
    title: string;
    artist: string;
    album?: string;
    albumCover?: string;
    language?: string;
    duration?: number; // NEW: provided by backend
  };
}

const UploadContent = () => {
  const navigate = useNavigate();
  const { setAlbumCover } = useDynamicTheme();
  const [songData, setSongData] = useState<SongData | null>(null);
  const [highlightMode, setHighlightMode] = useState<'word' | 'line'>('word');
  const [currentTime, setCurrentTime] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [audioElement, setAudioElement] = useState<HTMLAudioElement | null>(null);
  const [lyricSettings, setLyricSettings] = useState({
    fontSize: 100,
    fontFamily: 'Space Grotesk',
    textColor: 'hsl(var(--foreground))',
    glowIntensity: 30,
    highlightColor: 'hsl(var(--lyric-highlight))',
    lineSpacing: 1.5,
    letterSpacing: 0,
    textShadow: 0,
    animationSpeed: 1,
    blurEffect: 0
  });

  const handleLyricSettingsChange = (newSettings: any) => {
    setLyricSettings(prevSettings => ({
      ...prevSettings,
      ...newSettings
    }));
  };

  const handleSongLoad = (audioUrl: string, lyrics: any[], songInfo: any) => {
    setSongData({ audioUrl, lyrics, songInfo });
  };

  // Update dynamic theme when album cover changes
  useEffect(() => {
    if (songData?.songInfo?.albumCover) {
      setAlbumCover(songData.songInfo.albumCover);
    }
  }, [songData?.songInfo?.albumCover, setAlbumCover]);

  const handleAlbumCoverChange = (newCover: string) => {
    if (songData) {
      setSongData({
        ...songData,
        songInfo: { ...songData.songInfo, albumCover: newCover }
      });
    }
  };

  const handleSongInfoChange = (field: 'title' | 'artist' | 'album', value: string) => {
    if (songData) {
      setSongData({
        ...songData,
        songInfo: { ...songData.songInfo, [field]: value }
      });
    }
  };

  const handleTimeUpdate = (time: number) => {
    setCurrentTime(time);
  };

  const handlePlayStateChange = (playing: boolean) => {
    setIsPlaying(playing);
  };

  const handleAudioElementChange = (element: HTMLAudioElement | null) => {
    setAudioElement(element);
  };

  return (
    <div className="min-h-screen bg-gradient-background font-sans">
      <BeatReactiveBackground
        isPlaying={isPlaying} 
        currentTime={currentTime} 
        audioElement={audioElement}
      />
      
      {/* Header */}
      <header className="relative z-10 p-4 flex justify-between items-center">
        <button 
          onClick={() => navigate('/')}
          className="flex items-center space-x-2 hover:opacity-80 transition-opacity duration-300 group"
        >
          <div className="w-8 h-8 bg-gradient-primary rounded-lg shadow-glow group-hover:shadow-lg group-hover:scale-105 transition-all duration-300" />
          <div className="font-display font-extrabold group-hover:text-primary transition-colors duration-300">
            {"VerseMotion".split('').map((char, index) => (
              <TextPressure
                key={index}
                text={char}
                flex={true}
                weight={true}
                width={true}
                italic={false}
                alpha={false}
                stroke={false}
                textColor="hsl(var(--foreground))"
                minFontSize={18}
                maxFontSize={26}
                className="inline-block"
                neighborEffect={true}
                neighborStrength={0.8}
              />
            ))}
          </div>
        </button>
        <div className="flex items-center space-x-2">
          <DynamicThemeToggle />
          <ThemeToggle />
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 flex flex-col min-h-[calc(100vh-80px)]">
        {songData ? (
          <>
            {/* Song Info */}
            <div className="p-6 flex justify-center">
              <SongInfo 
                {...songData.songInfo} 
                onAlbumCoverChange={handleAlbumCoverChange}
                onSongInfoChange={handleSongInfoChange}
              />
            </div>

            {/* Lyric Customizer */}
            <LyricCustomizer 
              settings={lyricSettings}
              onSettingsChange={handleLyricSettingsChange}
            />

            {/* Lyrics Display */}
            <LyricDisplay
              lyrics={songData.lyrics}
              currentTime={currentTime}
              isPlaying={isPlaying}
              settings={lyricSettings}
            />

            {/* Progressive Indicator */}
            <ProgressiveIndicator
              lyrics={songData.lyrics}
              currentTime={currentTime}
              isPlaying={isPlaying}
              onHighlightModeChange={setHighlightMode}
            />
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center p-8">
            <SongUploader onSongLoad={handleSongLoad} />
          </div>
        )}

        {/* Audio Player */}
        <div className="mt-auto">
          <AudioPlayer
            audioUrl={songData?.audioUrl}
            duration={songData?.songInfo?.duration ?? 0}
            onTimeUpdate={handleTimeUpdate}
            onPlayStateChange={handlePlayStateChange}
            onAudioElementChange={handleAudioElementChange}
          />
        </div>

        {/* Guided Hints */}
        <GuidedHints onComplete={() => {}} currentPage="upload" />
      </main>
    </div>
  );
};

const Upload = () => (
  <DynamicThemeProvider>
    <UploadContent />
  </DynamicThemeProvider>
);

export default Upload;